// CS302 program1
//  Dinh Nguyen
//  A program to manage car rental service


#include "UI.h"
#include <iostream>
using namespace std;

int main(){
	cout << "*************************************************" << endl;
	cout << "** A car rental service created by Dinh Nguyen **" << endl;
	cout << "** For CS302 Prog 1                            **" <<endl << endl;
	cout << "*************************************************" << endl;
	RentalUI UI;
	UI.mainMenu();

	return 0;
}
	
